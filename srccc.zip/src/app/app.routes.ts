import { Routes } from '@angular/router';
import { AppShellComponent } from './app-shell.component';
import { AdventureworksDetailComponent } from './components/projects/adventureworks-detail/adventureworks-detail.component';

export const routes: Routes = [
  { path: '', component: AppShellComponent },
  { path: 'projects/adventureworks', component: AdventureworksDetailComponent },
  { path: '**', redirectTo: '' },
];
